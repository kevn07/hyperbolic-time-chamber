# Starter Templates

This directory contains three identical copies of a minimal project boilerplate, one for each of the three technical interview sessions.

Use of the templates is optional. They're intended only to allow saving time creating new files, etc., at the start of each interview.

Please note that the template may not be relevant to all technical interview sessions because they don't involve writing code, or because those sessions use a more specific template provided during the interview.
