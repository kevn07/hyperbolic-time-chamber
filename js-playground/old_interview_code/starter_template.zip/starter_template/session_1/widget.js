console.log('JS loaded successfully!')
